
			<!--
			=============================================
				Partner Logo
			==============================================
			-->
			<div class="partner-section">
				<div class="container">
					<h2 class="text-center">Our Partners</h2>

					<div id="partenr-logo">
						<div class="item"><img src="https://klba.or.ke/images/partner/ilri.jpg" alt=""></div>
						<div class="item"><img src="https://klba.or.ke/images/partner/partner1.png" alt=""></div>
						<div class="item"><img src="https://klba.or.ke/images/partner/partner2.png" alt=""></div>
						<div class="item"><img src="https://klba.or.ke/images/partner/partner3.png" alt=""></div>
						<div class="item"><img src="https://klba.or.ke/images/partner/partner4.png" alt=""></div>
						<div class="item"><img src="https://klba.or.ke/images/partner/au-ibar_en.png" alt=""></div>
		
					</div>
				</div> <!-- /.container -->
			</div> <!-- /.partner-section --><?php /**PATH C:\Users\hp\Desktop\laravelprojects\Livestock\resources\views/Partners/Partners.blade.php ENDPATH**/ ?>