<style>
    .container__mission{
        padding: 20px;
        margin-top: 40px;
        margin-bottom: 30px;
    }
    .container__missionH3{
        text-align: center;
        color: #1c478e;
        font-weight: bold;
    }
    .container__mission>p{
        text-align: center;
        font-size: 15px;
        font-weight: bold;

    }
</style>
<div class="container__mission">
    <h2 class="container__missionH3">
        Our Vision
    </h2>
    <p>
        Our vision is to be the best  Livestock Registration and Recording
         center and bring Livestock Registration and Recording attain International standards of excellence.
    </p>
    <h2 class="container__missionH3">
        Our Mission
    </h2>
    <p>
        Our mission is to improve Livestock breeding through effective and efficient  Livestock Registration and Recording and help farmers,
    Institutions and entrepreneurs reach an international market with our expertise in recording and registration.
    </p>

</div>
<?php /**PATH C:\Users\hp\Desktop\laravelprojects\Livestock\resources\views/Mission/mission.blade.php ENDPATH**/ ?>