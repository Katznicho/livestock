
<!--cards-->
<div class="container">
    <div class="container__border">

        <div class="row">
            <!--col-->
            <div class="col-md-3 col-sm-6 col-xs-12  border__right " >

                <div class="blog-single-post ">

                    <!--a word-->
                    <h2 class="post__heading">
                        TRAINING IN BREEDING
                    </h2>
                        
                    <!-- a word-->
                    <div class="img image__section"
                
                    ><img src="https://klba.or.ke/images/icons/husbandry.png" 
                    class="center__image1"
                    alt="Image">
                </div>
                    <div class="post">

                        <p class="post__content">
                            We offer advice to farmers on breeding and importance of record 
                            keeping and livestock registration.

                        </p>
                    </div> <!-- /.post -->
                </div> <!-- /.blog-single-post -->
            </div> <!-- /.col -->
            <!--col-->
            <!--col-->
            <div class="col-md-3 col-sm-6 col-xs-12  border__right " >

                <div class="blog-single-post ">

                    <!--a word-->
                    <h2 class="post__heading">
                        LIVE STOCK REGISTRATION
                    </h2>
                        
                    <!-- a word-->
                    <div class="img image__section"
                
                    ><img src="https://klba.or.ke/images/icons/livestock-reg.png" 
                    class="center__image4"
                    alt="Image">
                </div>
                    <div class="post">

                        <p class="post__content">
                            We offer advice to farmers on breeding and importance of record 
                            keeping and livestock registration.

                        </p>
                    </div> <!-- /.post -->
                </div> <!-- /.blog-single-post -->
            </div> <!-- /.col -->
            <!--col-->
            <!--col-->
            <div class="col-md-3 col-sm-6 col-xs-12  border__right " >

                <div class="blog-single-post ">

                    <!--a word-->
                    <h2 class="post__heading">
                        PERFORMANCE RECORDING
                    </h2>
                        
                    <!-- a word-->
                    <div class="img image__section"
                
                    ><img src="https://klba.or.ke/images/icons/recording.jpg" 
                    class="center__image2"
                    alt="Image">
                </div>
                    <div class="post">

                        <p class="post__content">
                            We offer advice to farmers on breeding and importance of record 
                            keeping and livestock registration.

                        </p>
                    </div> <!-- /.post -->
                </div> <!-- /.blog-single-post -->
            </div> <!-- /.col -->
            <!--col-->
            <!--col-->
            <div class="col-md-3 col-sm-6 col-xs-12 " >

                <div class="blog-single-post ">

                    <!--a word-->
                    <h2 class="post__heading">
                        RECORDING
                    </h2>
                        
                    <!-- a word-->
                    <div class="img image__section"
                
                    ><img src="https://klba.or.ke/images/icons/certificates.jpg" 
                    class="center__image3"
                    alt="Image">
                </div>
                    <div class="post">

                        <p class="post__content">
                            We offer advice to farmers on breeding and importance of record 
                            keeping and livestock registration.

                        </p>
                    </div> <!-- /.post -->
                </div> <!-- /.blog-single-post -->
            </div> <!-- /.col -->
            <!--col-->
        </div>

    </div>
</div>
<!--cards--><?php /**PATH C:\Users\hp\Desktop\laravelprojects\Livestock\resources\views/Blogs/HomeCard.blade.php ENDPATH**/ ?>