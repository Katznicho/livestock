<style>
    .blogCards__container{
         background-color: #fff!important;

    }
    .blogCards{
      margin-top: 20px !important;
    }
    .blogs__newsandevents{
        text-align: center;
        padding: 30px;
        margin:10px 5px;
        font-size: 25px;
      color: #5A5A5A;
      font-weight: 800
    }
    .border__bottom{
        border-bottom: 10px solid gold !important;
    }
    .blog__readMore{
        text-align: center;
        color: #fff;
        background: gold;
        padding: 5px;
        cursor: pointer;
    }
</style>
<!--
			=============================================
				Our Blog 
			==============================================
			-->
            <div class="blogCards__container">
                  <div class="blogs__newsandevents">NEWS AND EVENTS</div>
                     <div class="blogCards">
                           <!--blog container-->
                 <div class="our-blog ">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-3 col-sm-6 col-xs-12 ">

                                <div class="blog-single-post border__bottom">
                                    <div class="img"><img src="https://t4.ftcdn.net/jpg/00/91/44/65/240_F_91446502_BJgzuq2JOjPVp4ZkkxO1CAEkTxSVJvSK.jpg" alt="Image"></div>
                                    <div class="post">
                                        <small><span class="color3"></span>August 7, 2018</small>
                                        <h5><a href="#" class="tran3s">
                                            Training Boosts Uganda’s Foot and Mouth Resilience
                                        </a></h5>
                                        <p>
                                            First, they presented the current FMD situation and the FMD global strategy, 
                                            with emphasis on the progressive control pathway.
                                             Then, the participants drafted a document to upgrade the Nat...

                                        </p>
                                        <ul>
                                            <li> </li>
                                            <li>
                                                <button class="blog__readMore">Read More</button>
                                            </li>
                                        </ul>
                                    </div> <!-- /.post -->
                                </div> <!-- /.blog-single-post -->
                            </div> <!-- /.col -->
                            <div class="col-md-3 col-sm-6 col-xs-12">
                                <div class="blog-single-post border__bottom">
                                    <div class="img"><img src="https://t4.ftcdn.net/jpg/00/91/44/65/240_F_91446502_BJgzuq2JOjPVp4ZkkxO1CAEkTxSVJvSK.jpg" alt="Image"></div>
                                    <div class="post">
                                        <small><span class="color3"></span>August 7, 2018</small>
                                        <h5><a href="#" class="tran3s">
                                            Training Boosts Uganda’s Foot and Mouth Resilience
                                        </a></h5>
                                        <p>
                                            First, they presented the current FMD situation and the FMD global strategy, 
                                            with emphasis on the progressive control pathway.
                                             Then, the participants drafted a document to upgrade the Nat...

                                        </p>
                                        <ul>
                                            <li> </li>
                                            <li>
                                                <button class="blog__readMore">Read More</button>
                                            </li>
                                        </ul>
                                    </div> <!-- /.post -->
                                </div> <!-- /.blog-single-post -->
                            </div> <!-- /.col -->
                            <div class="col-md-3 col-sm-6 col-xs-12">
                                <div class="blog-single-post border__bottom">
                                    <div class="img"><img src="https://t4.ftcdn.net/jpg/00/91/44/65/240_F_91446502_BJgzuq2JOjPVp4ZkkxO1CAEkTxSVJvSK.jpg" alt="Image"></div>
                                    <div class="post">
                                        <small><span class="color3"></span>August 7, 2018</small>
                                        <h5><a href="#" class="tran3s">
                                            Training Boosts Uganda’s Foot and Mouth Resilience
                                        </a></h5>
                                        <p>
                                            First, they presented the current FMD situation and the FMD global strategy, 
                                            with emphasis on the progressive control pathway.
                                             Then, the participants drafted a document to upgrade the Nat...

                                        </p>
                                        <ul>
                                            <li> </li>
                                            <li>
                                                <button class="blog__readMore">Read More</button>
                                            </li>
                                        </ul>
                                    </div> <!-- /.post -->
                                </div> <!-- /.blog-single-post -->
                            </div> <!-- /.col -->
                            <div class="col-md-3 col-sm-6 col-xs-12">
                                <div class="blog-single-post border__bottom">
                                    <div class="img"><img src="https://t4.ftcdn.net/jpg/00/91/44/65/240_F_91446502_BJgzuq2JOjPVp4ZkkxO1CAEkTxSVJvSK.jpg" alt="Image"></div>
                                    <div class="post">
                                        <small><span class="color3"></span>August 7, 2018</small>
                                        <h5><a href="#" class="tran3s">
                                            Training Boosts Uganda’s Foot and Mouth Resilience
                                        </a></h5>
                                        <p>
                                            First, they presented the current FMD situation and the FMD global strategy, 
                                            with emphasis on the progressive control pathway.
                                             Then, the participants drafted a document to upgrade the Nat...

                                        </p>
                                        <ul>
                                            <li> </li>
                                            <li>
                                                <button class="blog__readMore">Read More</button>
                                            </li>
                                        </ul>
                                    </div> <!-- /.post -->
                                </div> <!-- /.blog-single-post -->
                            </div> <!-- /.col -->
    
                        </div> <!-- /.row -->
                    </div> <!-- /.container -->
                </div> <!-- /.our-blog -->
                 <!--blog container-->

                     </div>
                
            </div>
			
			
			
		<?php /**PATH C:\Users\hp\Desktop\laravelprojects\Livestock\resources\views/Blogs/BlogCards.blade.php ENDPATH**/ ?>